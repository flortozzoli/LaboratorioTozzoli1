package ar.org.centro8.java.entities;

public class Radio {
    String marcaRadio;
    int potencia;

    
    public Radio(String marcaRadio, int potencia) {
        this.marcaRadio = marcaRadio;
        this.potencia = potencia;
    }


    @Override
    public String toString() {
        return "Radio [marca=" + marcaRadio + ", potencia=" + potencia + "]";
    }

    
}
