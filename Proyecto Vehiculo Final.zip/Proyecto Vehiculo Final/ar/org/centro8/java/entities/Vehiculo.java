package ar.org.centro8.java.entities;

    public abstract class Vehiculo { 
        protected String marca;
        private String color;
        private String modelo;
        private double precio;
        private Radio radio;
    
        /**
         * Constructror sin radio y sin precio
         */
        public Vehiculo(String marca, String color, String modelo) {
            this.marca = marca;
            this.color = color;
            this.modelo = modelo;
        }
    
        /**
         * Constructor con Radio y sin precio
         */
        public Vehiculo(String marca, String color, String modelo, String marcaRadio, int potencia) {
            this.marca = marca;
            this.color = color;
            this.modelo = modelo;
            this.radio = new Radio(marcaRadio, 0);
        }
    
       

        /**
         * Constructor con Precio y sin Radio
         **/
        public Vehiculo(String marca, String color, String modelo, double precio) {
            this.marca = marca;
            this.color = color;
            this.modelo = modelo;
            this.precio = precio;
        }
    


        /**
         * Constructor con Radio y con Precio
          */
        public Vehiculo(String marca, String color, String modelo, double precio, String marcaRadio, int potencia) {
            this.marca = marca;
            this.color = color;
            this.modelo = modelo;
            this.precio = precio;
            this.radio = new Radio(marcaRadio, 0);
            
        }
    
        
        @Override
        public String toString() {
            return "[marca=" + marca + ", color=" + color + ", modelo=" + modelo + ", precio=" + precio
                    + ", radio=" + radio + "]";
        }
    
    
        public String getMarca() {
            return marca;
        }
    
        public String getColor() {
            return color;
        }
    
        public String getModelo() {
            return modelo;
        }
    
        public double getPrecio() {
            return precio;
        }
    
       
    
        public void cambiarRadio(String marcaRadio, int potencia) {
            this.radio = new Radio(marcaRadio, 0);
        }

        public Radio getRadio() {
            return radio;
        }
    
}
