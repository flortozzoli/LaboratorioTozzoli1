package ar.org.centro8.java.entities;

public final class Colectivo extends Vehiculo {

    public Colectivo(String marca, String color, String modelo) {
        super(marca, color, modelo);

    }

    public Colectivo(String marca, String color, String modelo, String marcaRadio, int potencia) {
        super(marca, color, modelo, marcaRadio, potencia);
    }


    public Colectivo(String marca, String color, String modelo, double precio) {
        super(marca, color, modelo, precio);
    }

    public Colectivo(String marca, String color, String modelo, double precio, String marcaRadio, int potencia) {
        super(marca, color, modelo, precio, marcaRadio, potencia);
    }


    @Override
    public String toString() {
        return "COLECTIVO "+ super.toString();
    
    }
    
    
    
}
