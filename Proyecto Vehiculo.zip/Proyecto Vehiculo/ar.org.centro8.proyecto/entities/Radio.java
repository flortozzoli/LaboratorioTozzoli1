public class Radio {
        String marca;
        int potencia;

        
        public Radio(String marca, int potencia) {
            this.marca = marca;
            this.potencia = potencia;
        }


        @Override
        public String toString() {
            return "Radio [marca=" + marca + ", potencia=" + potencia + "]";
        }


        public void setMarca(String marca) {
            this.marca = marca;
        }


        public void setPotencia(int potencia) {
            this.potencia = potencia;
        }


        public String getMarca() {
            return marca;
        }


        public int getPotencia() {
            return potencia;
        }


        }
   
     


       
       
   
   
