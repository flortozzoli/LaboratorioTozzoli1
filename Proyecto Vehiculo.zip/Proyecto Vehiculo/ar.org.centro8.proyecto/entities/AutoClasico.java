public class AutoClasico extends Vehiculo {

    public AutoClasico(String marca, String color, String modelo) {
        super(marca, color, modelo);
    }

    public AutoClasico(String marca, String color, String modelo, Radio radio) {
        super(marca, color, modelo, radio);
    }

    public AutoClasico(String marca, String color, String modelo, double precio) {
        super(marca, color, modelo, precio);
    }

    public AutoClasico(String marca, String color, String modelo, double precio, Radio radio) {
        super(marca, color, modelo, precio, radio);
    }
    
    @Override
    public void setRadio(Radio radio) {
        super.setRadio(radio);
    }

    @Override
    public String toString() {
        return "Auto Clasico: "+ super.toString();

        
    
    
}
}