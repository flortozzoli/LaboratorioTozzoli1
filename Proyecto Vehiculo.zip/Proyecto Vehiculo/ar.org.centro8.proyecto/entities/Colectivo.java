public final class Colectivo extends Vehiculo {

    public Colectivo(String marca, String color, String modelo) {
        super(marca, color, modelo);

    }

    public Colectivo(String marca, String color, String modelo, Radio radio) {
        super(marca, color, modelo, radio);
    }

    public Colectivo(String marca, String color, String modelo, double precio) {
        super(marca, color, modelo, precio);
    }

    public Colectivo(String marca, String color, String modelo, double precio, Radio radio) {
        super(marca, color, modelo, precio, radio);
    }


    @Override
    public String toString() {
        return "COLECTIVO "+ super.toString();
    
    }

    @Override
    public void setRadio(Radio radio) {
        super.setRadio(radio);
    }

    
    
    
}
