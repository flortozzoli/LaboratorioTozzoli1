public class AutoNuevo extends Vehiculo {

    public AutoNuevo(String marca, String color, String modelo, Radio radio) {
        super(marca, color, modelo, radio);
    }

    public AutoNuevo(String marca, String color, String modelo, double precio, Radio radio) {
        super(marca, color, modelo, precio, radio);
    }


    @Override
    public String toString() {
        return "Auto Nuevo: " + super.toString() ;
    }

    @Override
    public void setRadio(Radio radio) {
        super.setRadio(radio);
    }
    
}
