import javax.sound.sampled.SourceDataLine;

public class TestVehiculo {
    public static void main(String[] args) {

        System.out.println("------COLECTIVOS--------");
        System.out.println("---COLECTIVO 1 sin precio y sin radio----");
        Colectivo colectivo1=new Colectivo("mercedes venz", "blanco y rojo", "132");
        System.out.println(colectivo1);
        

        System.out.println("---COLECTIVO 2 sin precio y con radio----");
        Colectivo colectivo2= new Colectivo("MV", "gris", "111", new Radio("pionner", 100000));
        System.out.println(colectivo2);

        System.out.println("----COLECTIVO 3 con precio y sin radio ");
        Colectivo colectivo3= new Colectivo("isuzu", "verde", "65", 1000);
        System.out.println(colectivo3);

        System.out.println("----COLECTIVO 4 con precio y con radio ------");
        Colectivo colectivo4= new Colectivo("Peugeot", "rojo", "88", 20000, new Radio("Sony", 500));
        System.out.println(colectivo4);

        System.out.println("------------AUTOS CLASICOS--------------");
        System.out.println("----------AUTO CLASICO 1 sin radio y sin precio----------");
        AutoClasico autoclasico1=new AutoClasico("Ford", "Rojo", "Mustang");
        System.out.println(autoclasico1);

        System.out.println("----------AUTO CLASICO 2 con radio y sin precio----------");
        AutoClasico autoclasico2= new AutoClasico("Chevrolet", "AMarillo", "Camaro", new Radio("pionner", 200));
        System.out.println(autoclasico2);

        System.out.println("----------AUTO CLASICO 3 sin radio y con precio----------");
        AutoClasico autoclasico3= new AutoClasico("Chevrolet", "lila", "Corvete", 10000000);
        System.out.println(autoclasico3);

        System.out.println("----------AUTO CLASICO 4 con radio y con precio----------");
        AutoClasico autoclasico4= new AutoClasico("Peugeot", "gris", "504", 00000, new Radio("Sony", 200));
        System.out.println(autoclasico4);

        autoclasico4.setRadio(null);

        
        System.out.println("------------AUTOS NUEVOS--------------");
        System.out.println("-------------AUTO NUEVO 1 con radio y sin precio---------");
        AutoNuevo autonuevo1= new AutoNuevo("Peugeot", "rojo", "208", new Radio("Sony", 500));
        System.out.println(autonuevo1);

        System.out.println("-----------AUTO NUEVO 2 con radio y con precio------");
        AutoNuevo autonuevo2=new AutoNuevo("Ford", "Blanco", "ECOSPORT", 5000000, new Radio("Pioneer", 700));
        System.out.println(autonuevo2);





        





        

        
    }


        
}
